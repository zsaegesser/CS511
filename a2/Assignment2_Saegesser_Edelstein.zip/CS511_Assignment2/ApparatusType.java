package Assignment2;

//Zach Saegesser and Ryan Edelstein
//I pledge my honor that I have abided by the Stevens honor System

import java.util.Random;

public enum ApparatusType {
	LEGPRESSMACHINE, BARBELL, HACKSQUATMACHINE, LEGEXTENSIONMACHINE, 
	LEGCURLMACHINE, LATPULLDOWNMACHINE, PECDECKMACHINE, CABLECROSSOVERMACHINE;

	static ApparatusType RandomApparatusType() {
		return ApparatusType.values()[new Random().nextInt(ApparatusType
				.values().length)];
	}
}